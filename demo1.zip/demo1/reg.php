<?php 
include('dbcon.php');

$r1 = $_POST['r'];
$n1 = $_POST['n'];
$e1 = $_POST['e'];
$m1 = $_POST['m'];

$query = "INSERT INTO studentreg VALUES('$r1','$n1','$e1','$m1')";

echo $query;
if(mysqli_query($con, $query))
{
echo "<h1> Inserted </h1>";
}
else
{
echo "fail";
}

?>
 <a href="index.html" > MENU </a > 
</html>
</head>
