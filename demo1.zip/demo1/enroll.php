<html>
<head>
<?php 
include('dbcon.php');
include('session.php'); 

$g = $_POST['g'];
$n = $_POST['n'];
$c = $_POST['c'];
$d = $_POST['d'];
$e = $_POST['e'];
$m = $_POST['m'];
$query = "INSERT INTO Reg VALUES('$g','$n','$c','$d','$e','$m')";

echo $query;
if(mysqli_query($con, $query))
{
echo "<h1> Inserted </h1>";
}
else
{
echo "fail";
}

?>
 <a href="home.php" > MENU </a > 
</html>
</head>


 

