<?php
include('dbcon.php');

$r1 = $_POST['r'];
$query = "delete from studentreg where RollNo='$r1'";
echo $query;
if(mysqli_query($con, $query))
{
echo "<h1> Deleted</h1>";
}
else
{
echo "fail";
}


?>
