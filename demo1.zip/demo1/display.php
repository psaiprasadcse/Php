<?php 
include('dbcon.php');
 

$result=mysqli_query($con,"select * from studentreg");
  

 ?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="form-wrapper"> 
    <center><h3>This is Student List </h3></center>
<table border="1" align="center">
<th>RollNo</th>
<th>Name</th>
<th>email</th>
<th>Mobile</th>
<tr>
<?php while ($row=mysqli_fetch_row($result))
    { ?>
<td><?php echo $row['0']; ?> </td>
<td><?php echo $row['1']; ?> </td>
<td><?php echo $row['2']; ?> </td>
<td><?php echo $row['3']; ?> </td>

</tr>
<?  } ?>

<a href="index.html" > MENU </a > 
 
</div>

</body>
</html>
